import React, { useState } from 'react';

function getNowDate() {
  const d = new Date();
  return d.toISOString().slice(0,10);
}

export default function TransactionForm() {
  const [type, setType] = useState('penjualan');
  const [date, setDate] = useState(getNowDate());
  const [product, setProduct] = useState('');
  const [qty, setQty] = useState(1);
  const [price, setPrice] = useState(0);
  const [note, setNote] = useState('');
  const [msg, setMsg] = useState('');

  const save = (e) => {
    e.preventDefault();
    const trx = {
      id: 'T' + Date.now(),
      date,
      type,
      product,
      qty: Number(qty),
      price: Number(price),
      total: Number(qty) * Number(price),
      note
    };
    // save to localStorage
    const arr = JSON.parse(localStorage.getItem('transactions') || '[]');
    arr.push(trx);
    localStorage.setItem('transactions', JSON.stringify(arr));
    setMsg('Transaksi disimpan');
    setProduct('');
    setQty(1);
    setPrice(0);
    setNote('');
    setTimeout(()=>setMsg(''), 2000);
  };

  return (
    <div className="card">
      <h3>Input Transaksi</h3>
      <form onSubmit={save} className="form">
        <label>Tanggal</label>
        <input type="date" value={date} onChange={e=>setDate(e.target.value)} required />
        <label>Jenis</label>
        <select value={type} onChange={e=>setType(e.target.value)}>
          <option value="penjualan">Penjualan</option>
          <option value="pengeluaran">Pengeluaran</option>
        </select>
        <label>Produk / Keterangan</label>
        <input value={product} onChange={e=>setProduct(e.target.value)} required />
        <label>Jumlah</label>
        <input type="number" min="1" value={qty} onChange={e=>setQty(e.target.value)} required />
        <label>Harga Satuan (Rp)</label>
        <input type="number" min="0" value={price} onChange={e=>setPrice(e.target.value)} required />
        <label>Catatan</label>
        <input value={note} onChange={e=>setNote(e.target.value)} />
        <div className="actions">
          <button className="btn" type="submit">Simpan</button>
        </div>
        {msg && <div className="success">{msg}</div>}
      </form>
    </div>
  );
}